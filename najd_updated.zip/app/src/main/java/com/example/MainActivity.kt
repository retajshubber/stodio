package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.NajdViewModel
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.NajdTheme

class MainActivity : ComponentActivity() {

    private val viewModel: NajdViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()
            val currentLanguage by viewModel.currentLanguage.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val isLoggedIn by viewModel.isLoggedIn.collectAsState()

            val layoutDirection = if (currentLanguage == "AR") LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                NajdTheme(darkTheme = isDarkMode) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                            when (screen) {
                                "splash" -> SplashScreen(
                                    onTimeout = {
                                        if (isLoggedIn) {
                                            viewModel.navigateTo("home")
                                        } else {
                                            viewModel.navigateTo("login")
                                        }
                                    }
                                )
                                "login" -> LoginScreen(
                                    viewModel = viewModel,
                                    onLoginSuccess = { viewModel.navigateTo("home") },
                                    onNavigateBack = { viewModel.navigateTo("home") }
                                )
                                "home" -> HomeScreen(
                                    viewModel = viewModel,
                                    onNavigate = { destination ->
                                        viewModel.navigateTo(destination)
                                    }
                                )
                                "schedule" -> ScheduleScreen(
                                    viewModel = viewModel,
                                    onNavigateNext = { viewModel.navigateTo("map") }
                                )
                                "map" -> MapScreen(
                                    viewModel = viewModel,
                                    onNavigate = { destination ->
                                        viewModel.navigateTo(destination)
                                    }
                                )
                                "analytics" -> AnalyticsScreen(
                                    viewModel = viewModel,
                                    onNavigate = { destination ->
                                        viewModel.navigateTo(destination)
                                    }
                                )
                                "profile" -> ProfileScreen(
                                    viewModel = viewModel,
                                    onNavigate = { destination ->
                                        viewModel.navigateTo(destination)
                                    }
                                )
                                else -> HomeScreen(
                                    viewModel = viewModel,
                                    onNavigate = { destination ->
                                        viewModel.navigateTo(destination)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
