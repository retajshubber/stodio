package com.example.data

import kotlinx.coroutines.flow.Flow

class LectureRepository(private val lectureDao: LectureDao) {
    val allLectures: Flow<List<LectureEntity>> = lectureDao.getAllLectures()

    suspend fun insert(lecture: LectureEntity): Long = lectureDao.insertLecture(lecture)

    suspend fun delete(lecture: LectureEntity) = lectureDao.deleteLecture(lecture)

    suspend fun deleteById(id: Long) = lectureDao.deleteLectureById(id)

    suspend fun prepopulateIfEmpty() {
        if (lectureDao.getCount() == 0) {
            lectureDao.insertLecture(
                LectureEntity(
                    subjectName = "العمارة النجدية",
                    day = "الأحد",
                    startTime = "09:00 ص",
                    location = "قاعة 12"
                )
            )
            lectureDao.insertLecture(
                LectureEntity(
                    subjectName = "اللغة الإنجليزية",
                    day = "الأحد",
                    startTime = "11:30 ص",
                    location = "مبنى ج"
                )
            )
            lectureDao.insertLecture(
                LectureEntity(
                    subjectName = "الإحصاء الحيوي",
                    day = "الاثنين",
                    startTime = "01:00 م",
                    location = "معمل 4"
                )
            )
        }
    }
}
