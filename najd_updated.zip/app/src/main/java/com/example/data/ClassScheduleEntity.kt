package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "class_schedule")
data class ClassScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseCode: String,
    val courseName: String,
    val dayOfWeek: String, // e.g. "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday" or "الأحد", "الاثنين", ...
    val timeSlot: String,  // e.g. "08:00 AM - 09:30 AM"
    val roomLocation: String, // e.g. "Hall 102 - Building B"
    val instructorName: String = "",
    val colorTag: String = "#008080"
)
