package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ClassScheduleDao {
    @Query("SELECT * FROM class_schedule ORDER BY id ASC")
    fun getAllSchedules(): Flow<List<ClassScheduleEntity>>

    @Query("SELECT * FROM class_schedule WHERE dayOfWeek = :day ORDER BY timeSlot ASC")
    fun getSchedulesForDay(day: String): Flow<List<ClassScheduleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: ClassScheduleEntity): Long

    @Delete
    suspend fun deleteSchedule(schedule: ClassScheduleEntity)

    @Query("DELETE FROM class_schedule WHERE id = :id")
    suspend fun deleteScheduleById(id: Long)

    @Query("SELECT COUNT(*) FROM class_schedule")
    suspend fun getCount(): Int
}
