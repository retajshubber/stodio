package com.example.data

import kotlinx.coroutines.flow.Flow

class ClassScheduleRepository(private val dao: ClassScheduleDao) {
    val allSchedules: Flow<List<ClassScheduleEntity>> = dao.getAllSchedules()

    fun getSchedulesForDay(day: String): Flow<List<ClassScheduleEntity>> = dao.getSchedulesForDay(day)

    suspend fun insertSchedule(schedule: ClassScheduleEntity): Long = dao.insertSchedule(schedule)

    suspend fun deleteSchedule(schedule: ClassScheduleEntity) = dao.deleteSchedule(schedule)

    suspend fun deleteScheduleById(id: Long) = dao.deleteScheduleById(id)

    suspend fun prepopulateIfEmpty() {
        if (dao.getCount() == 0) {
            val sampleSchedules = listOf(
                ClassScheduleEntity(
                    courseCode = "CS 301",
                    courseName = "هندسة البرمجيات والأنظمة",
                    dayOfWeek = "الأحد",
                    timeSlot = "08:00 ص - 09:30 ص",
                    roomLocation = "مبنى ب - قاعة 102",
                    instructorName = "د. أحمد النجدي",
                    colorTag = "#008080"
                ),
                ClassScheduleEntity(
                    courseCode = "ARCH 210",
                    courseName = "مبادئ العمارة السعودية النجدية",
                    dayOfWeek = "الأحد",
                    timeSlot = "10:00 ص - 11:30 ص",
                    roomLocation = "مبنى ج - مدرج 4",
                    instructorName = "د. سارة الراشد",
                    colorTag = "#7B1FA2"
                ),
                ClassScheduleEntity(
                    courseCode = "MATH 202",
                    courseName = "المعادلات التفاضلية والتفاضل",
                    dayOfWeek = "الاثنين",
                    timeSlot = "09:00 ص - 10:30 ص",
                    roomLocation = "المجمع العلمي - معامل 3",
                    instructorName = "د. خالد العمر",
                    colorTag = "#1976D2"
                ),
                ClassScheduleEntity(
                    courseCode = "ENG 105",
                    courseName = "الكتابة الأكاديمية والاتصال",
                    dayOfWeek = "الاثنين",
                    timeSlot = "11:00 ص - 12:30 م",
                    roomLocation = "مبنى أ - قاعة 205",
                    instructorName = "أ. مريم العتيبي",
                    colorTag = "#388E3C"
                ),
                ClassScheduleEntity(
                    courseCode = "AI 410",
                    courseName = "مقدمة في الذكاء الاصطناعي",
                    dayOfWeek = "الثلاثاء",
                    timeSlot = "08:30 ص - 10:00 ص",
                    roomLocation = "معمل الحاسب الرئيسي",
                    instructorName = "د. فيصل السالم",
                    colorTag = "#008080"
                ),
                ClassScheduleEntity(
                    courseCode = "PHYS 101",
                    courseName = "الفيزياء العامة والتطبيقية",
                    dayOfWeek = "الأربعاء",
                    timeSlot = "10:00 ص - 11:30 ص",
                    roomLocation = "مبنى العلوم - مختبر 12",
                    instructorName = "د. طارق الحكيم",
                    colorTag = "#E65100"
                ),
                ClassScheduleEntity(
                    courseCode = "IS 220",
                    courseName = "قواعد البيانات ونظم المعلومات",
                    dayOfWeek = "الخميس",
                    timeSlot = "09:30 ص - 11:00 ص",
                    roomLocation = "مبنى ب - قاعة 301",
                    instructorName = "د. نورة الشمري",
                    colorTag = "#008080"
                )
            )

            for (schedule in sampleSchedules) {
                dao.insertSchedule(schedule)
            }
        }
    }
}
