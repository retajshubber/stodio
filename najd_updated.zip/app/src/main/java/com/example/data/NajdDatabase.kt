package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [LectureEntity::class, ClassScheduleEntity::class], version = 2, exportSchema = false)
abstract class NajdDatabase : RoomDatabase() {
    abstract fun lectureDao(): LectureDao
    abstract fun classScheduleDao(): ClassScheduleDao

    companion object {
        @Volatile
        private var INSTANCE: NajdDatabase? = null

        fun getDatabase(context: Context): NajdDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NajdDatabase::class.java,
                    "najd_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
