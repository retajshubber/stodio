package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ClassScheduleEntity
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBackgroundLight
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.ErrorOrangeRed
import com.example.ui.theme.PrimaryContainerTeal
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.SecondaryContainer
import com.example.ui.theme.TertiaryViolet

@Composable
fun WeeklyClassScheduleComponent(
    schedules: List<ClassScheduleEntity>,
    isDarkMode: Boolean,
    isArabic: Boolean,
    onAddSchedule: (courseCode: String, courseName: String, dayOfWeek: String, timeSlot: String, roomLocation: String, instructorName: String) -> Unit,
    onDeleteSchedule: (ClassScheduleEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDayFilter by remember { mutableStateOf(if (isArabic) "الكل" else "All") }
    var isAddFormExpanded by remember { mutableStateOf(false) }

    // Form states
    var courseCodeInput by remember { mutableStateOf("") }
    var courseNameInput by remember { mutableStateOf("") }
    var selectedDayInput by remember { mutableStateOf(if (isArabic) "الأحد" else "Sunday") }
    var timeSlotInput by remember { mutableStateOf("") }
    var roomLocationInput by remember { mutableStateOf("") }
    var instructorInput by remember { mutableStateOf("") }

    val daysList = if (isArabic) {
        listOf("الكل", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس")
    } else {
        listOf("All", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday")
    }

    val formDays = if (isArabic) {
        listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس")
    } else {
        listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday")
    }

    val cardBg = if (isDarkMode) CardBackgroundDark else CardBackgroundLight
    val cardBorder = if (isDarkMode) CardBorderDark else Color.Transparent

    val filteredSchedules = remember(schedules, selectedDayFilter, isArabic) {
        if (selectedDayFilter == "الكل" || selectedDayFilter == "All") {
            schedules
        } else {
            schedules.filter { it.dayOfWeek.contains(selectedDayFilter, ignoreCase = true) }
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("weekly_class_schedule_component"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PrimaryContainerTeal.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = PrimaryTeal,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = if (isArabic) "الجدول الأسبوعي الجامعي" else "Weekly Class Schedule",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isArabic) "المحاضرات، الأوقات والقاعات" else "Time slots, course names & room locations",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Add Toggle Button
                IconButton(
                    onClick = { isAddFormExpanded = !isAddFormExpanded },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PrimaryContainerTeal)
                        .testTag("toggle_add_schedule_button")
                ) {
                    Icon(
                        imageVector = if (isAddFormExpanded) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = "Toggle Add",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Stats Quick Summary Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isArabic) "إجمالي المحاضرات" else "Total Classes",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${schedules.size}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryTeal
                    )
                }
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(20.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isArabic) "المفلترة حالياً" else "Showing",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${filteredSchedules.size}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TertiaryViolet
                    )
                }
            }

            // Expandable Add Schedule Form (Room Database Insert)
            AnimatedVisibility(
                visible = isAddFormExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_schedule_form_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "إضافة مقرر جديد إلى قاعدة البيانات" else "Add New Class to Room Database",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryTeal
                        )

                        // Row 1: Course Code & Course Name
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = courseCodeInput,
                                onValueChange = { courseCodeInput = it },
                                label = { Text(if (isArabic) "رمز المقرر" else "Course Code", fontSize = 11.sp) },
                                placeholder = { Text("CS 101", fontSize = 11.sp) },
                                modifier = Modifier
                                    .weight(0.4f)
                                    .testTag("input_course_code"),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )

                            OutlinedTextField(
                                value = courseNameInput,
                                onValueChange = { courseNameInput = it },
                                label = { Text(if (isArabic) "اسم المقرر" else "Course Name", fontSize = 11.sp) },
                                placeholder = { Text(if (isArabic) "هندسة الحاسب" else "Computer Eng", fontSize = 11.sp) },
                                modifier = Modifier
                                    .weight(0.6f)
                                    .testTag("input_course_name"),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )
                        }

                        // Day Choice Chips in Form
                        Text(
                            text = if (isArabic) "اختر اليوم:" else "Select Day:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(formDays) { day ->
                                val isSelected = day == selectedDayInput
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) PrimaryTeal else MaterialTheme.colorScheme.surface)
                                        .clickable { selectedDayInput = day }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = day,
                                        fontSize = 11.sp,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        // Row 2: Time Slot & Room Location
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = timeSlotInput,
                                onValueChange = { timeSlotInput = it },
                                label = { Text(if (isArabic) "الفترة / الوقت" else "Time Slot", fontSize = 11.sp) },
                                placeholder = { Text("08:00 AM - 09:30 AM", fontSize = 11.sp) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_time_slot"),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )

                            OutlinedTextField(
                                value = roomLocationInput,
                                onValueChange = { roomLocationInput = it },
                                label = { Text(if (isArabic) "القاعة / المكان" else "Room Location", fontSize = 11.sp) },
                                placeholder = { Text("G-102", fontSize = 11.sp) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_room_location"),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )
                        }

                        // Row 3: Instructor
                        OutlinedTextField(
                            value = instructorInput,
                            onValueChange = { instructorInput = it },
                            label = { Text(if (isArabic) "اسم المحاضر / أستاذ المادة" else "Instructor Name", fontSize = 11.sp) },
                            placeholder = { Text(if (isArabic) "د. محمد " else "Dr. Alex", fontSize = 11.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_instructor"),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface
                            )
                        )

                        // Save Button
                        Button(
                            onClick = {
                                onAddSchedule(
                                    courseCodeInput,
                                    courseNameInput,
                                    selectedDayInput,
                                    timeSlotInput,
                                    roomLocationInput,
                                    instructorInput
                                )
                                courseCodeInput = ""
                                courseNameInput = ""
                                timeSlotInput = ""
                                roomLocationInput = ""
                                instructorInput = ""
                                isAddFormExpanded = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("save_class_schedule_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
                        ) {
                            Text(
                                text = if (isArabic) "حفظ في قاعدة البيانات" else "Save Class Schedule",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // Days Horizontal Navigation Tabs
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(daysList) { day ->
                    val isSelected = day == selectedDayFilter
                    val chipBg by animateColorAsState(
                        targetValue = if (isSelected) PrimaryTeal else MaterialTheme.colorScheme.surfaceVariant,
                        label = "dayChipBg"
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(chipBg)
                            .clickable { selectedDayFilter = day }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                            .testTag("day_filter_chip_$day")
                    ) {
                        Text(
                            text = day,
                            fontSize = 12.sp,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            // Schedule Cards List
            if (filteredSchedules.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isArabic) "لا يوجد محاضرات لهذا اليوم" else "No classes scheduled for this day",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    filteredSchedules.forEach { classSchedule ->
                        ClassScheduleCardItem(
                            item = classSchedule,
                            isDarkMode = isDarkMode,
                            isArabic = isArabic,
                            onDelete = { onDeleteSchedule(classSchedule) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ClassScheduleCardItem(
    item: ClassScheduleEntity,
    isDarkMode: Boolean,
    isArabic: Boolean,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("class_schedule_item_${item.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: Course Code, Day Badge, and Delete Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(PrimaryTeal)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = item.courseCode,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(PrimaryContainerTeal.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = item.dayOfWeek,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = PrimaryTeal
                        )
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Class",
                        tint = ErrorOrangeRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Course Name
            Text(
                text = item.courseName,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Details Grid: Time Slot & Room Location
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Time Slot Tag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = PrimaryTeal,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = item.timeSlot,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Room Location Tag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = TertiaryViolet,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = item.roomLocation,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Instructor Tag (if present)
            if (item.instructorName.isNotBlank()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = item.instructorName,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
