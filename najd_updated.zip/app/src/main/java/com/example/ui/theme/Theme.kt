package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryContainerTeal,       // Primary Accent — unchanged in dark per spec
    onPrimary = Color.White,
    primaryContainer = PrimaryTealHeaderDark, // #0A5148 — darkened header/button teal
    onPrimaryContainer = Color.White,
    secondary = MutedTealSurfaceDark,
    onSecondary = PrimaryContainerTeal,
    tertiary = AIRouteDark,               // #6FC2FF — brightened AI route/chart color
    onTertiary = Color.White,
    tertiaryContainer = AIBadgeDark,      // #5A2A82 — brightened AI badge background
    onTertiaryContainer = Color.White,
    background = BackgroundDark,
    onBackground = OnSurfaceDark,
    surface = CardBackgroundDark,
    onSurface = OnSurfaceDark,
    surfaceVariant = SurfaceContainerDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    outline = OnSurfaceVariantDark,
    outlineVariant = OutlineVariantDark,
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryTeal,                 // #037F71 Primary Dark Teal
    onPrimary = Color.White,
    primaryContainer = PrimaryContainerTeal, // #52BCA3 Primary Accent
    onPrimaryContainer = OnPrimaryContainer, // #003B38 Logo Dark Teal
    secondary = SecondaryTeal,             // #52BCA3 Primary Accent
    onSecondary = Color.White,
    secondaryContainer = SecondaryContainer, // #AECFD0 Muted Teal Surface
    onSecondaryContainer = OnSecondaryContainer, // #52BCA3 active state
    tertiary = TertiaryViolet,             // #56AEFF AI Route/Chart
    onTertiary = Color.White,
    tertiaryContainer = TertiaryContainerViolet, // #431D63 AI Badge bg
    onTertiaryContainer = OnTertiaryContainer,   // white bold text
    background = BackgroundLight,          // #E0E5E9
    onBackground = OnSurfaceLight,         // #2B2F2D Text Primary
    surface = SurfaceLight,                // #FFFCF2 Main Cards
    onSurface = OnSurfaceLight,            // #2B2F2D Text Primary
    surfaceVariant = SurfaceContainerLight, // #FFFFFF Input field bg
    onSurfaceVariant = OnSurfaceVariantLight, // #333652 Text Secondary
    outline = OutlineLight,                // #333652
    outlineVariant = OutlineVariantLight,  // #C7D9E5 Input Border
)

@Composable
fun NajdTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

