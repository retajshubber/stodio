package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.StatusType
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBackgroundLight
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.PrimaryContainerTeal
import com.example.ui.theme.PrimaryFixed
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.StatusExcellent
import com.example.ui.theme.StatusExcellentBg
import com.example.ui.theme.StatusHeavy
import com.example.ui.theme.StatusHeavyBg
import com.example.ui.theme.StatusLight
import com.example.ui.theme.StatusLightBg
import com.example.ui.theme.StatusModerate
import com.example.ui.theme.StatusModerateBg
import com.example.ui.theme.TertiaryViolet

data class RouteSegment(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val densityLevel: StatusType,
    val avgSpeedKmH: Int,
    val vehicleCount: Int,
    val densityPercent: Int,
    val bottleneckAr: String,
    val bottleneckEn: String,
    val xStartFrac: Float,
    val yStartFrac: Float,
    val xEndFrac: Float,
    val yEndFrac: Float
)

data class UniversityRoute(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val statusType: StatusType,
    val statusAr: String,
    val statusEn: String,
    val avgSpeedKmH: Int,
    val travelTimeMinutes: Int,
    val delayMinutes: Int,
    val distanceKm: Double,
    val peakHours: String,
    val segments: List<RouteSegment>
)

@Composable
fun TrafficDashboardCard(
    isDarkMode: Boolean,
    isArabic: Boolean,
    modifier: Modifier = Modifier
) {
    var selectedRouteId by remember { mutableStateOf("route_1") }
    var selectedSegmentId by remember { mutableStateOf<String?>(null) }
    var densityFilter by remember { mutableStateOf("ALL") } // "ALL", "HEAVY", "SMOOTH"
    var isSimulatingScan by remember { mutableStateOf(false) }

    val cardBg = if (isDarkMode) CardBackgroundDark else CardBackgroundLight
    val cardBorder = if (isDarkMode) CardBorderDark else Color.Transparent

    val routes = remember {
        listOf(
            UniversityRoute(
                id = "route_1",
                nameAr = "بوابة الجامعة الرئيسية",
                nameEn = "Main Campus Gate",
                statusType = StatusType.EXCELLENT,
                statusAr = "سلس للغاية",
                statusEn = "Very Smooth",
                avgSpeedKmH = 75,
                travelTimeMinutes = 10,
                delayMinutes = 0,
                distanceKm = 6.4,
                peakHours = "08:00 AM - 09:00 AM",
                segments = listOf(
                    RouteSegment(
                        id = "seg_1_1",
                        nameAr = "قطاع البوابة الجنوبية المباشرة",
                        nameEn = "South Gate Direct Boulevard",
                        densityLevel = StatusType.EXCELLENT,
                        avgSpeedKmH = 82,
                        vehicleCount = 14,
                        densityPercent = 15,
                        bottleneckAr = "تدفق سلس - لا يوجد ازدحام",
                        bottleneckEn = "Smooth flow - No congestion",
                        xStartFrac = 0.12f, yStartFrac = 0.80f,
                        xEndFrac = 0.28f, yEndFrac = 0.70f
                    ),
                    RouteSegment(
                        id = "seg_1_2",
                        nameAr = "ممر التفتيش والتوجيه الذكي",
                        nameEn = "Smart Checkpoint Loop",
                        densityLevel = StatusType.LIGHT,
                        avgSpeedKmH = 68,
                        vehicleCount = 28,
                        densityPercent = 32,
                        bottleneckAr = "تباطؤ خفيف عند بوابة النماذج",
                        bottleneckEn = "Slight slowdown at digital gate",
                        xStartFrac = 0.28f, yStartFrac = 0.70f,
                        xEndFrac = 0.45f, yEndFrac = 0.58f
                    ),
                    RouteSegment(
                        id = "seg_1_3",
                        nameAr = "الدوار المركزي الرئيسي",
                        nameEn = "Central Campus Hub",
                        densityLevel = StatusType.MODERATE,
                        avgSpeedKmH = 48,
                        vehicleCount = 45,
                        densityPercent = 58,
                        bottleneckAr = "تقاطع حافلات النقل الترددي",
                        bottleneckEn = "Shuttle bus junction crossing",
                        xStartFrac = 0.45f, yStartFrac = 0.58f,
                        xEndFrac = 0.55f, yEndFrac = 0.52f
                    )
                )
            ),
            UniversityRoute(
                id = "route_2",
                nameAr = "ممر الكليات الشمالي",
                nameEn = "North Academic Corridor",
                statusType = StatusType.HEAVY,
                statusAr = "ازدحام شديد",
                statusEn = "Heavy Traffic",
                avgSpeedKmH = 22,
                travelTimeMinutes = 28,
                delayMinutes = 12,
                distanceKm = 8.1,
                peakHours = "07:30 AM - 09:30 AM",
                segments = listOf(
                    RouteSegment(
                        id = "seg_2_1",
                        nameAr = "ممر قوس كلية الهندسة",
                        nameEn = "Engineering Arch Link",
                        densityLevel = StatusType.MODERATE,
                        avgSpeedKmH = 36,
                        vehicleCount = 52,
                        densityPercent = 65,
                        bottleneckAr = "تنزيل الطلاب والمنتسبين",
                        bottleneckEn = "Student drop-off zone",
                        xStartFrac = 0.35f, yStartFrac = 0.25f,
                        xEndFrac = 0.42f, yEndFrac = 0.40f
                    ),
                    RouteSegment(
                        id = "seg_2_2",
                        nameAr = "تقاطع المكتبة المركزية",
                        nameEn = "Central Library Junction",
                        densityLevel = StatusType.HEAVY,
                        avgSpeedKmH = 14,
                        vehicleCount = 110,
                        densityPercent = 92,
                        bottleneckAr = "ازدحام شديد عند إشارة المشاة",
                        bottleneckEn = "Severe delay at pedestrian signal",
                        xStartFrac = 0.42f, yStartFrac = 0.40f,
                        xEndFrac = 0.52f, yEndFrac = 0.55f
                    ),
                    RouteSegment(
                        id = "seg_2_3",
                        nameAr = "شارع الحاسبات والذكاء الاصطناعي",
                        nameEn = "IT & Computing Avenue",
                        densityLevel = StatusType.HEAVY,
                        avgSpeedKmH = 18,
                        vehicleCount = 94,
                        densityPercent = 88,
                        bottleneckAr = "تكدس المركبات عند الموقف 3",
                        bottleneckEn = "Queue at Parking Lot 3",
                        xStartFrac = 0.52f, yStartFrac = 0.55f,
                        xEndFrac = 0.62f, yEndFrac = 0.70f
                    )
                )
            ),
            UniversityRoute(
                id = "route_3",
                nameAr = "سريع المجمع العلمي",
                nameEn = "Science Quad Expressway",
                statusType = StatusType.LIGHT,
                statusAr = "حركة خفيفة",
                statusEn = "Light Traffic",
                avgSpeedKmH = 68,
                travelTimeMinutes = 12,
                delayMinutes = 2,
                distanceKm = 9.5,
                peakHours = "08:15 AM - 08:45 AM",
                segments = listOf(
                    RouteSegment(
                        id = "seg_3_1",
                        nameAr = "الطريق السريع الخارجي",
                        nameEn = "Outer Campus Ring Highway",
                        densityLevel = StatusType.EXCELLENT,
                        avgSpeedKmH = 88,
                        vehicleCount = 18,
                        densityPercent = 12,
                        bottleneckAr = "تدفق سريع ممتاز",
                        bottleneckEn = "High speed smooth flow",
                        xStartFrac = 0.35f, yStartFrac = 0.25f,
                        xEndFrac = 0.58f, yEndFrac = 0.18f
                    ),
                    RouteSegment(
                        id = "seg_3_2",
                        nameAr = "نفق مجمع البحوث والابتكار",
                        nameEn = "Research Complex Tunnel",
                        densityLevel = StatusType.LIGHT,
                        avgSpeedKmH = 72,
                        vehicleCount = 32,
                        densityPercent = 28,
                        bottleneckAr = "تباطؤ خفيف عند مدخل النفق",
                        bottleneckEn = "Minor tunnel entry deceleration",
                        xStartFrac = 0.58f, yStartFrac = 0.18f,
                        xEndFrac = 0.78f, yEndFrac = 0.25f
                    ),
                    RouteSegment(
                        id = "seg_3_3",
                        nameAr = "وصلة المجمع الطبي",
                        nameEn = "Medical Quad Link",
                        densityLevel = StatusType.LIGHT,
                        avgSpeedKmH = 64,
                        vehicleCount = 38,
                        densityPercent = 35,
                        bottleneckAr = "عبور سيارات الطوارئ",
                        bottleneckEn = "Emergency medical access route",
                        xStartFrac = 0.78f, yStartFrac = 0.25f,
                        xEndFrac = 0.88f, yEndFrac = 0.35f
                    )
                )
            ),
            UniversityRoute(
                id = "route_4",
                nameAr = "طريق السكن الجامعي",
                nameEn = "Student Dorms Avenue",
                statusType = StatusType.MODERATE,
                statusAr = "كثافة متوسطة",
                statusEn = "Moderate Traffic",
                avgSpeedKmH = 42,
                travelTimeMinutes = 17,
                delayMinutes = 5,
                distanceKm = 5.2,
                peakHours = "01:00 PM - 02:30 PM",
                segments = listOf(
                    RouteSegment(
                        id = "seg_4_1",
                        nameAr = "شارع السكن الجنوبي",
                        nameEn = "South Dorms Parkway",
                        densityLevel = StatusType.MODERATE,
                        avgSpeedKmH = 42,
                        vehicleCount = 48,
                        densityPercent = 50,
                        bottleneckAr = "خروج الحافلات الترددية",
                        bottleneckEn = "Shuttle bus exit corridor",
                        xStartFrac = 0.50f, yStartFrac = 0.55f,
                        xEndFrac = 0.65f, yEndFrac = 0.65f
                    ),
                    RouteSegment(
                        id = "seg_4_2",
                        nameAr = "تقاطع المطعم المركزي",
                        nameEn = "Central Dining Hall Crossing",
                        densityLevel = StatusType.HEAVY,
                        avgSpeedKmH = 20,
                        vehicleCount = 85,
                        densityPercent = 82,
                        bottleneckAr = "عبور كثيف للطلاب في وقت الغداء",
                        bottleneckEn = "Lunch break pedestrian surge",
                        xStartFrac = 0.65f, yStartFrac = 0.65f,
                        xEndFrac = 0.76f, yEndFrac = 0.75f
                    ),
                    RouteSegment(
                        id = "seg_4_3",
                        nameAr = "مضمار المجمع الرياضي",
                        nameEn = "Sports Complex Link",
                        densityLevel = StatusType.EXCELLENT,
                        avgSpeedKmH = 78,
                        vehicleCount = 15,
                        densityPercent = 18,
                        bottleneckAr = "طريق مفتوح هادئ",
                        bottleneckEn = "Open quiet roadway",
                        xStartFrac = 0.76f, yStartFrac = 0.75f,
                        xEndFrac = 0.88f, yEndFrac = 0.82f
                    )
                )
            )
        )
    }

    val selectedRoute = routes.find { it.id == selectedRouteId } ?: routes.first()

    val (statusBg, statusTextColor, statusIcon) = when (selectedRoute.statusType) {
        StatusType.EXCELLENT -> Triple(StatusExcellentBg, StatusExcellent, Icons.Default.Bolt)
        StatusType.LIGHT -> Triple(StatusLightBg, StatusLight, Icons.Default.DirectionsCar)
        StatusType.MODERATE -> Triple(StatusModerateBg, StatusModerate, Icons.Default.Speed)
        StatusType.HEAVY -> Triple(StatusHeavyBg, StatusHeavy, Icons.Default.Warning)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("university_traffic_dashboard_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PrimaryContainerTeal.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Traffic,
                            contentDescription = null,
                            tint = PrimaryTeal,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = if (isArabic) "حالة طرق الجامعة الحية" else "University Live Commute",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isArabic) "خريطة وتفاعل كثافة القطاعات" else "Interactive Canvas & Segment Density",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // AI Live Badge
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(TertiaryViolet)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = if (isArabic) "تتبع حي" else "LIVE SCAN",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Route Selector Horizontal Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(routes, key = { it.id }) { route ->
                    val isSelected = route.id == selectedRouteId
                    val chipBg by animateColorAsState(
                        targetValue = if (isSelected) PrimaryTeal else MaterialTheme.colorScheme.surfaceVariant,
                        label = "chipBg"
                    )
                    val chipTextColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(chipBg)
                            .clickable {
                                selectedRouteId = route.id
                                selectedSegmentId = null
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("route_chip_${route.id}")
                    ) {
                        Text(
                            text = if (isArabic) route.nameAr else route.nameEn,
                            color = chipTextColor,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            // Interactive Canvas Component with Route Segments & Density Highlights
            InteractiveCampusCanvas(
                selectedRoute = selectedRoute,
                selectedSegmentId = selectedSegmentId,
                densityFilter = densityFilter,
                onSelectSegment = { selectedSegmentId = it },
                onToggleFilter = { densityFilter = it },
                isDarkMode = isDarkMode,
                isArabic = isArabic
            )

            // Segment Density Breakdown Card
            SegmentBreakdownSection(
                selectedRoute = selectedRoute,
                selectedSegmentId = selectedSegmentId,
                onSelectSegment = { selectedSegmentId = it },
                isArabic = isArabic
            )

            // Active Route Overview Detail
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(14.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isArabic) selectedRoute.nameAr else selectedRoute.nameEn,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Status Badge
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(statusBg)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = statusIcon,
                                    contentDescription = null,
                                    tint = statusTextColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (isArabic) selectedRoute.statusAr else selectedRoute.statusEn,
                                    color = statusTextColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Grid of 3 Live Indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Average Speed Gauge
                        MetricTile(
                            icon = Icons.Default.Speed,
                            title = if (isArabic) "متوسط السرعة" else "Avg Speed",
                            value = "${selectedRoute.avgSpeedKmH} ${if (isArabic) "كم/س" else "km/h"}",
                            modifier = Modifier.weight(1f)
                        )

                        // Estimated Travel Time
                        MetricTile(
                            icon = Icons.Default.AccessTime,
                            title = if (isArabic) "زمن الرحلة" else "Travel Time",
                            value = "${selectedRoute.travelTimeMinutes} ${if (isArabic) "د" else "m"}",
                            modifier = Modifier.weight(1f)
                        )

                        // Expected Delay
                        MetricTile(
                            icon = Icons.Default.Warning,
                            title = if (isArabic) "التأخير المتوقع" else "Delay",
                            value = if (selectedRoute.delayMinutes > 0) "+${selectedRoute.delayMinutes} ${if (isArabic) "د" else "m"}" else (if (isArabic) "لا يوجد" else "None"),
                            modifier = Modifier.weight(1f),
                            valueColor = if (selectedRoute.delayMinutes > 5) StatusHeavy else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Interactive Refresh CTA
            Button(
                onClick = {
                    isSimulatingScan = !isSimulatingScan
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("simulate_traffic_scan_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryContainerTeal,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isArabic) "تحديث ماسح المرور والكثافة المباشر" else "Refresh Live Commute Scan",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun InteractiveCampusCanvas(
    selectedRoute: UniversityRoute,
    selectedSegmentId: String?,
    densityFilter: String,
    onSelectSegment: (String?) -> Unit,
    onToggleFilter: (String) -> Unit,
    isDarkMode: Boolean,
    isArabic: Boolean,
    modifier: Modifier = Modifier
) {
    val mapBgColor = if (isDarkMode) Color(0xFF1E262B) else Color(0xFFE8F1EF)
    val gridLineColor = if (isDarkMode) Color(0xFF2C3940) else Color(0xFFD0E1DD)
    val zoneParkColor = if (isDarkMode) Color(0xFF1B3D2F) else Color(0xFFC8E6C9)
    val buildingColor = if (isDarkMode) Color(0xFF2A363F) else Color(0xFFD4E3E0)

    val infiniteTransition = rememberInfiniteTransition(label = "canvasGlow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(mapBgColor)
            .border(1.dp, PrimaryTeal.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            .testTag("interactive_campus_canvas")
    ) {
        // Canvas Drawing Layer
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Grid Background Lines
            val gridStep = 28.dp.toPx()
            var x = 0f
            while (x < width) {
                drawLine(
                    color = gridLineColor,
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1f
                )
                x += gridStep
            }
            var y = 0f
            while (y < height) {
                drawLine(
                    color = gridLineColor,
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
                y += gridStep
            }

            // 2. Campus Zone Parks & Building Blocks
            drawRoundRect(
                color = zoneParkColor,
                topLeft = Offset(width * 0.45f, height * 0.15f),
                size = Size(width * 0.22f, height * 0.3f),
                cornerRadius = CornerRadius(12f, 12f)
            )

            drawRoundRect(
                color = buildingColor,
                topLeft = Offset(width * 0.08f, height * 0.65f),
                size = Size(width * 0.18f, height * 0.22f),
                cornerRadius = CornerRadius(8f, 8f)
            )

            drawRoundRect(
                color = buildingColor,
                topLeft = Offset(width * 0.28f, height * 0.12f),
                size = Size(width * 0.15f, height * 0.25f),
                cornerRadius = CornerRadius(8f, 8f)
            )

            drawRoundRect(
                color = buildingColor,
                topLeft = Offset(width * 0.72f, height * 0.18f),
                size = Size(width * 0.2f, height * 0.25f),
                cornerRadius = CornerRadius(8f, 8f)
            )

            drawRoundRect(
                color = buildingColor,
                topLeft = Offset(width * 0.65f, height * 0.62f),
                size = Size(width * 0.22f, height * 0.26f),
                cornerRadius = CornerRadius(8f, 8f)
            )

            // 3. Draw Background Road Base Network (Neutral)
            val roadWidth = 14f
            val baseRoadColor = if (isDarkMode) Color(0xFF37474F) else Color(0xFFCFD8DC)

            // Draw full route base
            selectedRoute.segments.forEach { segment ->
                val pStart = Offset(width * segment.xStartFrac, height * segment.yStartFrac)
                val pEnd = Offset(width * segment.xEndFrac, height * segment.yEndFrac)

                drawLine(
                    color = baseRoadColor,
                    start = pStart,
                    end = pEnd,
                    strokeWidth = roadWidth + 4f,
                    cap = StrokeCap.Round
                )
            }

            // 4. Highlight Specific Segments with Color-Coded Traffic Density
            selectedRoute.segments.forEach { segment ->
                val pStart = Offset(width * segment.xStartFrac, height * segment.yStartFrac)
                val pEnd = Offset(width * segment.xEndFrac, height * segment.yEndFrac)

                val segmentColor = when (segment.densityLevel) {
                    StatusType.EXCELLENT -> StatusExcellent
                    StatusType.LIGHT -> StatusLight
                    StatusType.MODERATE -> StatusModerate
                    StatusType.HEAVY -> StatusHeavy
                }

                // Check Density Filter (ALL vs HEAVY vs SMOOTH)
                val matchesFilter = when (densityFilter) {
                    "HEAVY" -> segment.densityLevel == StatusType.HEAVY || segment.densityLevel == StatusType.MODERATE
                    "SMOOTH" -> segment.densityLevel == StatusType.EXCELLENT || segment.densityLevel == StatusType.LIGHT
                    else -> true
                }

                val effectiveAlpha = if (matchesFilter) 1.0f else 0.25f
                val isSegmentSelected = selectedSegmentId == segment.id

                // Draw density segment line
                drawLine(
                    color = segmentColor.copy(alpha = effectiveAlpha),
                    start = pStart,
                    end = pEnd,
                    strokeWidth = if (isSegmentSelected) roadWidth + 8f else roadWidth,
                    cap = StrokeCap.Round
                )

                // If segment is selected or heavy, draw pulsing glow outline
                if (isSegmentSelected || (segment.densityLevel == StatusType.HEAVY && matchesFilter)) {
                    drawLine(
                        color = segmentColor.copy(alpha = glowAlpha * effectiveAlpha),
                        start = pStart,
                        end = pEnd,
                        strokeWidth = roadWidth + 14f,
                        cap = StrokeCap.Round
                    )

                    // Dashed overlay indicator
                    val path = Path().apply {
                        moveTo(pStart.x, pStart.y)
                        lineTo(pEnd.x, pEnd.y)
                    }
                    drawPath(
                        path = path,
                        color = Color.White.copy(alpha = 0.8f),
                        style = Stroke(
                            width = 3f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f),
                            cap = StrokeCap.Round
                        )
                    )
                }

                // Draw vehicle dots along segment
                val midX = (pStart.x + pEnd.x) / 2
                val midY = (pStart.y + pEnd.y) / 2
                drawCircle(
                    color = Color.White,
                    radius = 4f,
                    center = Offset(midX, midY)
                )
            }
        }

        // Overlay Interactive Nodes / Segment Pins on Canvas
        selectedRoute.segments.forEach { segment ->
            val isSelected = selectedSegmentId == segment.id
            val statusColor = when (segment.densityLevel) {
                StatusType.EXCELLENT -> StatusExcellent
                StatusType.LIGHT -> StatusLight
                StatusType.MODERATE -> StatusModerate
                StatusType.HEAVY -> StatusHeavy
            }

            // Calculate midpoint for pin positioning
            val midXFrac = (segment.xStartFrac + segment.xEndFrac) / 2
            val midYFrac = (segment.yStartFrac + segment.yEndFrac) / 2

            Box(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(
                            x = (320 * midXFrac - 18).dp,
                            y = (210 * midYFrac - 14).dp
                        )
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) Color.White else statusColor)
                        .border(
                            width = 2.dp,
                            color = if (isSelected) statusColor else Color.White,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            onSelectSegment(if (isSelected) null else segment.id)
                        }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                        .testTag("segment_pin_${segment.id}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) statusColor else Color.White)
                        )
                        Text(
                            text = "${segment.densityPercent}%",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) statusColor else Color.White
                        )
                    }
                }
            }
        }

        // Top Canvas Controls Header Bar (Filter Density Toggles & Map Title)
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Map Title Badge
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.90f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Map,
                    contentDescription = null,
                    tint = PrimaryTeal,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = if (isArabic) "خريطة قطاعات المسار" else "Route Canvas",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Density Filter Chips
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.90f))
                    .padding(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                FilterChipItem(
                    label = if (isArabic) "الكل" else "ALL",
                    isSelected = densityFilter == "ALL",
                    onClick = { onToggleFilter("ALL") }
                )
                FilterChipItem(
                    label = if (isArabic) "الكثيف" else "HEAVY",
                    isSelected = densityFilter == "HEAVY",
                    selectedBg = StatusHeavy,
                    onClick = { onToggleFilter("HEAVY") }
                )
                FilterChipItem(
                    label = if (isArabic) "السلس" else "SMOOTH",
                    isSelected = densityFilter == "SMOOTH",
                    selectedBg = StatusExcellent,
                    onClick = { onToggleFilter("SMOOTH") }
                )
            }
        }

        // Status Legend at Bottom Right
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.90f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendDot(StatusExcellent, if (isArabic) "سلس" else "Smooth")
            LegendDot(StatusLight, if (isArabic) "خفيف" else "Light")
            LegendDot(StatusModerate, if (isArabic) "متوسط" else "Moderate")
            LegendDot(StatusHeavy, if (isArabic) "كثيف" else "Heavy")
        }
    }
}

@Composable
private fun SegmentBreakdownSection(
    selectedRoute: UniversityRoute,
    selectedSegmentId: String?,
    onSelectSegment: (String?) -> Unit,
    isArabic: Boolean
) {
    val activeSegment = selectedRoute.segments.find { it.id == selectedSegmentId } ?: selectedRoute.segments.first()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("segment_breakdown_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AltRoute,
                        contentDescription = null,
                        tint = PrimaryTeal,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (isArabic) "تحليل كثافة القطاعات المسجلة" else "Color-Coded Segment Breakdown",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = if (isArabic) "انقر على القطاع للتحديد" else "Tap segment to highlight",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Horizontal Segment Selector Tabs
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(selectedRoute.segments) { segment ->
                    val isSelected = (selectedSegmentId == segment.id) || (selectedSegmentId == null && segment == selectedRoute.segments.first())
                    val segColor = when (segment.densityLevel) {
                        StatusType.EXCELLENT -> StatusExcellent
                        StatusType.LIGHT -> StatusLight
                        StatusType.MODERATE -> StatusModerate
                        StatusType.HEAVY -> StatusHeavy
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) segColor else MaterialTheme.colorScheme.surface)
                            .border(1.dp, segColor, RoundedCornerShape(10.dp))
                            .clickable { onSelectSegment(segment.id) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("segment_tab_${segment.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) Color.White else segColor)
                            )
                            Text(
                                text = if (isArabic) segment.nameAr else segment.nameEn,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Detailed Selected Segment Metrics Display
            val activeColor = when (activeSegment.densityLevel) {
                StatusType.EXCELLENT -> StatusExcellent
                StatusType.LIGHT -> StatusLight
                StatusType.MODERATE -> StatusModerate
                StatusType.HEAVY -> StatusHeavy
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, activeColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isArabic) activeSegment.nameAr else activeSegment.nameEn,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(activeColor.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${activeSegment.densityPercent}% ${if (isArabic) "كثافة الحركة" else "Density"}",
                                color = activeColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Progress Bar for Segment Density
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isArabic) "مستوى ازدحام القطاع" else "Segment Congestion Level",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${activeSegment.avgSpeedKmH} ${if (isArabic) "كم/س" else "km/h"}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = activeColor
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(activeSegment.densityPercent / 100f)
                                    .height(6.dp)
                                    .clip(CircleShape)
                                    .background(activeColor)
                            )
                        }
                    }

                    // Secondary Metrics (Vehicle count & Primary bottleneck)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = PrimaryTeal,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${if (isArabic) "عدد المركبات:" else "Vehicles:"} ${activeSegment.vehicleCount}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = activeColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = if (isArabic) activeSegment.bottleneckAr else activeSegment.bottleneckEn,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChipItem(
    label: String,
    isSelected: Boolean,
    selectedBg: Color = PrimaryTeal,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) selectedBg else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun MetricTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(8.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = PrimaryTeal,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = title,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            fontSize = 8.sp,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
    }
}
