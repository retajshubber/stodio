package com.example.ui.strings

/**
 * A bilingual string pair. Call it with `isArabic` to resolve the right text
 * at runtime — this matches the app's existing in-app language toggle
 * (NajdViewModel.currentLanguage), so no Android locale/resource-qualifier
 * system is needed.
 *
 * Usage: Strings.Login.title(isArabic)
 */
data class Bi(val ar: String, val en: String) {
    operator fun invoke(isArabic: Boolean): String = if (isArabic) ar else en
}

object Strings {

    object Login {
        val title = Bi("تسجيل الدخول", "Sign In")
        val email = Bi("البريد الإلكتروني", "Email Address")
        val password = Bi("كلمة المرور", "Password")
        val forgotPassword = Bi("نسيت كلمة المرور؟", "Forgot Password?")
        val logIn = Bi("دخول", "Log In")
        val orVia = Bi("أو عبر", "Or via")
        val noAccount = Bi("ما عندك حساب؟ سجّلي الآن", "Don't have an account? Register now")
        val invalidCredentials = Bi(
            "البريد أو كلمة المرور غير صحيحة",
            "Incorrect email or password"
        )
    }

    object Weather {
        val screenTitle = Bi("الطقس", "Weather")
        val location = Bi("مسقط، عُمان", "Muscat, Oman")
        val conditionClearHot = Bi("صافٍ، حار", "Clear, Hot")
        val humidity = Bi("رطوبة", "Humidity")
        val wind = Bi("رياح", "Wind")
        val windSpeedSample = Bi("١٢ كم/س", "12 km/h")
        val feelsLike = Bi("الشعور", "Feels like")
        val hourlyForecast = Bi("توقعات الساعة", "Hourly Forecast")
        val routeImpactTitle = Bi("تأثير الطقس على المسار", "Weather Impact on Your Route")
        val aiTag = Bi("ذكي", "AI")
        val routeImpactBody = Bi(
            "من المتوقع هطول أمطار خفيفة الساعة ٥ م، وقد يزيد ذلك زمن الرحلة على طريق مسقط " +
                "السريع بنسبة ١٠٪. يُنصح بالانطلاق مبكرًا.",
            "Light rain is expected around 5 PM, which may increase travel time on Muscat " +
                "Expressway by about 10%. Consider leaving earlier."
        )
        val expectedStatusModerate = Bi(
            "الحالة المتوقعة: متوسطة الساعة ٥ م",
            "Expected status: Moderate at 5 PM"
        )
        val hourNow = Bi("الآن", "Now")
    }

    object Home {
        val nextLecture = Bi("الحصة القادمة", "Next Lecture")
        val yourScheduleTodayOct = Bi("جدولك لليوم، ٢٤ أكتوبر", "Your Schedule Today, Oct 24")
        val am = Bi("صباحاً", "AM")
        val principlesOfNajdiArchitecture = Bi("مبادئ العمارة النجدية", "Principles of Najdi Architecture")
        val hallNoNdFloor = Bi("القاعة رقم ٤ - الطابق الثاني", "Hall No. 4 - 2nd Floor")
        val loginSignIn = Bi("تسجيل الدخول", "Login / Sign In")
        val calculateRoute = Bi("احسب المسار", "Calculate Route")
        val weeklyClassSchedule = Bi("الجدول الأسبوعي للجامعة", "Weekly Class Schedule")
        val tapToOpenTheDedicatedSchedule = Bi(
            "انقر لفتح شاشة الجدول المستقلة وقاعدة البيانات",
            "Tap to open the dedicated Schedule Screen & database"
        )
        val liveTrafficConditions = Bi("حالة الحركة المرورية الآن", "Live Traffic Conditions")
        val yourCurrentLocation = Bi("موقعك الحالي", "Your Current Location")
        val attendanceRegistration = Bi("تسجيل الحضور", "Attendance Registration")
        val ok = Bi("حسناً", "OK")
    }

    object Schedule {
        val sunday = Bi("الأحد", "Sunday")
        val studentSchedule = Bi("جدولك الدراسي", "Student Schedule")
        val subjectName = Bi("اسم المادة", "Subject Name")
        val eGSoftwareEngineering = Bi("مثال: هندسة البرمجيات", "e.g. Software Engineering")
        val day = Bi("اليوم", "Day")
        val startTime = Bi("وقت البدء", "Start Time")
        val locationHall = Bi("القاعة/المكان", "Location/Hall")
        val addLecture = Bi("إضافة محاضرة", "Add Lecture")
        val addedLectures = Bi("المحاضرات المضافة", "Added Lectures")
    }

    object Map {
        val map = Bi("الخريطة", "Map")
        val aiSmartRoute = Bi("طريق ذكي مقترح", "AI Smart Route")
        val goodTrafficQurum = Bi("حركة مرور جيدة - القرم", "Good Traffic - Qurum")
        val currentDestination = Bi("الوجهة الحالية", "Current Destination")
        val royalOperaHouseMuscat = Bi("دار الأوبرا السلطانية مسقط", "Royal Opera House Muscat")
        val estimatedArrival = Bi("الوصول المتوقع", "Estimated Arrival")
        val amM = Bi("9:12 ص (15 د)", "9:12 AM (15m)")
        val amM2 = Bi("9:15 ص (18 د)", "9:15 AM (18m)")
        val distance = Bi("المسافة", "Distance")
        val km = Bi("4.2 كم", "4.2 km")
        val tripInProgress = Bi("الرحلة قيد التقدم...", "Trip in Progress...")
        val startTrip = Bi("بدء الرحلة", "Start Trip")
        val recalculateRoute = Bi("إعادة التوجيه", "Recalculate Route")
    }

    object Analytics {
        val basedOnCurrentPatternsWePredict = Bi(
            "بناءً على الأنماط الحالية، نتوقع زيادة في حركة المرور بنسبة ١٥٪ في المنطقة الشمالية خلال الساعة القادمة. ننصح بتفعيل المسارات البديلة.",
            "Based on current patterns, we predict a 15% traffic volume increase in the Northern District over the next hour. We recommend activating alternative routes."
        )
        val analyticsDashboard = Bi("لوحة التحكم", "Analytics Dashboard")
        val lastUpdatedMinutesAgo = Bi("آخر تحديث: منذ دقيقتين", "Last updated: 2 minutes ago")
        val totalTrips = Bi("إجمالي الرحلات", "Total Trips")
        val totalTripsCount = Bi("١,٤٨٢", "1,482")
        val mostUsedBuilding = Bi("أكثر مبنى استخداماً", "Most Used Building")
        val regionA = Bi("المنطقة أ", "Region A")
        val weeklyTripVolume = Bi("حجم الرحلات الأسبوعي", "Weekly Trip Volume")
        val currentTrafficStatusLegend = Bi("حالة الحركة الحالية", "Current Traffic Status Legend")
        val excellent = Bi("ممتاز (Excellent)", "Excellent")
        val light = Bi("خفيف (Light)", "Light")
        val moderate = Bi("متوسط (Moderate)", "Moderate")
        val heavy = Bi("كثيف (Heavy)", "Heavy")
        val aiPredictiveAnalysis = Bi("توقعات الذكاء الاصطناعي", "AI Predictive Analysis")
        val viewRecommendations = Bi("عرض التوصيات والمسارات", "View Recommendations")
    }

    object Profile {
        fun idLabel(studentId: String, isArabic: Boolean) =
            if (isArabic) "الرقم الجامعي: $studentId" else "ID: $studentId"

        val activeStudent = Bi("طالب منتظم", "Active Student")
        val courses = Bi("المواد المسجلة", "Courses")
        val preferredRoute = Bi("طريق الجامعة المفضل", "Preferred Route")
        val basicStudentInformation = Bi("معلومات الطالب الأساسية", "Basic Student Information")
        val lock = Bi("قفل", "Lock")
        val edit = Bi("تعديل", "Edit")
        val studentFullName = Bi("اسم الطالب الكامل", "Student Full Name")
        val studentId = Bi("الرقم الجامعي (Student ID)", "Student ID")
        val collegeDepartment = Bi("الكلية / القسم الأكاديمي", "College / Department")
        val majorSpecialization = Bi("التخصص الدقيق", "Major / Specialization")
        val universityEmail = Bi("البريد الإلكتروني الجامعي", "University Email")
        val usualCampusRoute = Bi("طريق الجامعة المعتاد (لتنبيهات الازدحام)", "Usual Campus Route")
        val saveDetails = Bi("حفظ التعديلات", "Save Details")
        val accountNavigation = Bi("إعدادات وقواطع الحساب", "Account & Navigation")
        val switchAccount = Bi("تسجيل الدخول / تبديل", "Switch Account")
        val profileUpdated = Bi("تم الحفظ بنجاح", "Profile Updated")
        val ok = Bi("حسناً", "OK")
    }
}
