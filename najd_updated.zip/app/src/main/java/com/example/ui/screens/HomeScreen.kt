package com.example.ui.screens

import com.example.ui.strings.Strings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.NajdViewModel
import com.example.ui.StatusType
import com.example.ui.components.HeaderType
import com.example.ui.components.NajdBottomNavBar
import com.example.ui.components.NajdHeader
import com.example.ui.components.PreClassTrafficAlertBanner
import com.example.ui.components.TrafficNotificationSettingsCard
import com.example.ui.components.WeeklyClassScheduleComponent
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBackgroundLight
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.PrimaryContainerTeal
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.StatusExcellent
import com.example.ui.theme.StatusExcellentBg
import com.example.ui.theme.StatusHeavy
import com.example.ui.theme.StatusHeavyBg
import com.example.ui.theme.StatusLight
import com.example.ui.theme.StatusLightBg
import com.example.ui.theme.StatusModerate
import com.example.ui.theme.StatusModerateBg

import androidx.compose.material.icons.automirrored.filled.Login

@Composable
fun HomeScreen(
    viewModel: NajdViewModel,
    onNavigate: (String) -> Unit
) {
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isArabic = currentLanguage == "AR"

    val classSchedules by viewModel.classSchedules.collectAsState()

    val trafficRoads by viewModel.trafficRoads.collectAsState()
    val attendanceStatus by viewModel.attendanceStatus.collectAsState()

    val activeTrafficAlert by viewModel.activeTrafficAlert.collectAsState()
    val trafficAlertsEnabled by viewModel.trafficAlertsEnabled.collectAsState()

    val cardBg = if (isDarkMode) CardBackgroundDark else CardBackgroundLight
    val cardBorder = if (isDarkMode) CardBorderDark else Color.Transparent

    Scaffold(
        topBar = {
            NajdHeader(
                headerType = HeaderType.DASHBOARD,
                isDarkMode = isDarkMode,
                currentLanguage = currentLanguage,
                onToggleDarkMode = { viewModel.toggleDarkMode() },
                onToggleLanguage = { viewModel.toggleLanguage() },
                onLoginClick = { onNavigate("login") }
            )
        },
        bottomBar = {
            NajdBottomNavBar(
                currentScreen = "home",
                currentLanguage = currentLanguage,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 30-Min Pre-Class Traffic Heavy Warning Banner
                PreClassTrafficAlertBanner(
                    alert = activeTrafficAlert,
                    isDarkMode = isDarkMode,
                    isArabic = isArabic,
                    onDismiss = { viewModel.dismissTrafficAlert() },
                    onTakeAlternativeRoute = {
                        viewModel.dismissTrafficAlert()
                        onNavigate("map")
                    }
                )

                // Next Lecture Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("next_lecture_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = Strings.Home.nextLecture(isArabic),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = Strings.Home.yourScheduleTodayOct(isArabic),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(PrimaryContainerTeal.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = null,
                                    tint = PrimaryTeal
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Lecture Details Inner Container
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Time Box
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(end = 12.dp)
                            ) {
                                Text(
                                    text = "09:30",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryTeal
                                )
                                Text(
                                    text = Strings.Home.am(isArabic),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(36.dp)
                                    .background(MaterialTheme.colorScheme.outlineVariant)
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            // Details
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = Strings.Home.principlesOfNajdiArchitecture(isArabic),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = Strings.Home.hallNoNdFloor(isArabic),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Primary Action Button: Login Screen Access
                Button(
                    onClick = {
                        onNavigate("login")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("login_screen_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryTeal,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Login,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Strings.Home.loginSignIn(isArabic),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Secondary Action Button: Calculate Route
                Button(
                    onClick = {
                        onNavigate("map")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("calculate_route_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryContainerTeal,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Strings.Home.calculateRoute(isArabic),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Dedicated Schedule Screen Quick Access Banner Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate("schedule") }
                        .testTag("home_schedule_banner_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(PrimaryContainerTeal.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = PrimaryTeal,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = Strings.Home.weeklyClassSchedule(isArabic),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = Strings.Home.tapToOpenTheDedicatedSchedule(isArabic),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(PrimaryTeal)
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Open Schedule Screen",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Traffic Notification Settings Card
                TrafficNotificationSettingsCard(
                    isEnabled = trafficAlertsEnabled,
                    isDarkMode = isDarkMode,
                    isArabic = isArabic,
                    onToggleEnabled = { viewModel.toggleTrafficAlertsEnabled() },
                    onSimulateTestAlert = { viewModel.trigger30MinPreClassHeavyTrafficAlert() }
                )

                // Traffic Status Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("traffic_status_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Traffic,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = Strings.Home.liveTrafficConditions(isArabic),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Traffic Rows
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            trafficRoads.forEach { road ->
                                val (statusBg, statusTextColor, statusIcon) = when (road.statusType) {
                                    StatusType.EXCELLENT -> Triple(StatusExcellentBg, StatusExcellent, Icons.Default.Bolt)
                                    StatusType.LIGHT -> Triple(StatusLightBg, StatusLight, Icons.Default.TrendingFlat)
                                    StatusType.MODERATE -> Triple(StatusModerateBg, StatusModerate, Icons.Default.SlowMotionVideo)
                                    StatusType.HEAVY -> Triple(StatusHeavyBg, StatusHeavy, Icons.Default.Warning)
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isArabic) road.nameAr else road.nameEn,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(statusBg)
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = statusIcon,
                                                contentDescription = null,
                                                tint = statusTextColor,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = if (isArabic) road.statusAr else road.statusEn,
                                                color = statusTextColor,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Map Sneak-peek Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clickable { onNavigate("map") }
                        .testTag("map_sneak_peek_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AsyncImage(
                            model = "https://lh3.googleusercontent.com/aida-public/AB6AXuCFweSvtCZ_kKuV9UanoBGvfb-DD583XetTY2FAjNLgFOAMqMaKIF7DzCBRMFYetcefSxZrLD9-DAUzZb5-77kK_GHXkSUUwj2QGiIr362_WcC33BiU_-c6AC1TUaQesjR-0fXa0EcIU4sftZ1yK5uNgU9bTwnhKzJyz6inCJZLXGJIQnh5RnGazL-TRDytAA8brUK5TbFcF2aKKir8SoZqHlpk0MIr7vfpsRBJJTBo16fmQCGA7Edw",
                            contentDescription = "Map Vector Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )

                        // Current Location Badge Overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.9f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(PrimaryTeal)
                                )
                                Text(
                                    text = Strings.Home.yourCurrentLocation(isArabic),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Attendance Confirmation Dialog
    if (attendanceStatus != null) {
        AlertDialog(
            onDismissRequest = { viewModel.clearAttendanceDialog() },
            title = {
                Text(
                    text = Strings.Home.attendanceRegistration(isArabic),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(text = attendanceStatus ?: "")
            },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.clearAttendanceDialog() }
                ) {
                    Text(text = Strings.Home.ok(isArabic))
                }
            }
        )
    }
}
