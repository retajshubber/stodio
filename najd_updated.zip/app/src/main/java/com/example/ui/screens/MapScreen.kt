package com.example.ui.screens

import com.example.ui.strings.Strings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.NajdViewModel
import com.example.ui.components.HeaderType
import com.example.ui.components.NajdBottomNavBar
import com.example.ui.components.NajdHeader
import com.example.ui.components.PreClassTrafficAlertBanner
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBackgroundLight
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.PrimaryContainerTeal
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.SecondaryContainer
import com.example.ui.theme.TertiaryViolet

@Composable
fun MapScreen(
    viewModel: NajdViewModel,
    onNavigate: (String) -> Unit
) {
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isArabic = currentLanguage == "AR"

    val isTripStarted by viewModel.isTripStarted.collectAsState()
    val activeTrafficAlert by viewModel.activeTrafficAlert.collectAsState()

    val cardBg = if (isDarkMode) CardBackgroundDark else CardBackgroundLight
    val cardBorder = if (isDarkMode) CardBorderDark else Color.Transparent

    Scaffold(
        topBar = {
            NajdHeader(
                title = Strings.Map.map(isArabic),
                headerType = HeaderType.STANDARD,
                isDarkMode = isDarkMode,
                currentLanguage = currentLanguage,
                onToggleDarkMode = { viewModel.toggleDarkMode() },
                onToggleLanguage = { viewModel.toggleLanguage() },
                onBackClick = { onNavigate("home") },
                onLoginClick = { onNavigate("login") }
            )
        },
        bottomBar = {
            NajdBottomNavBar(
                currentScreen = "map",
                currentLanguage = currentLanguage,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Full-bleed Map Canvas Background Image
            AsyncImage(
                model = "https://lh3.googleusercontent.com/aida-public/AB6AXuCT10-crSG1tZB-KWc_62-7OZJQdhkIX3jxFkqQ9sS_f1qkix-7Wqs2VeNfvpF-I7hieyq0vKBhem0w0pY7JJtn_bTejgejttan96c-K-2GRLjWyAvaZ3IbmAlk-tiEbL9tzpkOGC-oqEjab_Ch9DE5QL8rUSsDKKfKm5J4e-Ym69l-j9sXGTJMlLT74qsABpiFGjoE4zCLm5w84KSkddwMndIxaK7eIukIJChpsUn_usYq2xaazPh4",
                contentDescription = "Map Canvas",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Vector Overlay for Route Line and Location Markers
            Canvas(modifier = Modifier.fillMaxSize()) {
                val routePath = Path().apply {
                    moveTo(size.width * 0.25f, size.height * 0.70f)
                    cubicTo(
                        size.width * 0.35f, size.height * 0.60f,
                        size.width * 0.45f, size.height * 0.45f,
                        size.width * 0.75f, size.height * 0.25f
                    )
                }

                // Route Path
                drawPath(
                    path = routePath,
                    color = Color(0xFF56AEFF),
                    style = Stroke(
                        width = 12f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 15f), 0f)
                    )
                )

                // Origin Circle Marker
                drawCircle(
                    color = Color(0xFF037F71),
                    radius = 20f,
                    center = Offset(size.width * 0.25f, size.height * 0.70f)
                )

                // Current Location Marker
                drawCircle(
                    color = Color.White,
                    radius = 28f,
                    center = Offset(size.width * 0.45f, size.height * 0.50f)
                )
                drawCircle(
                    color = Color(0xFF037F71),
                    radius = 20f,
                    center = Offset(size.width * 0.45f, size.height * 0.50f)
                )

                // Destination Marker Pin
                drawCircle(
                    color = Color(0xFFBA1A1A),
                    radius = 24f,
                    center = Offset(size.width * 0.75f, size.height * 0.25f)
                )
            }

            // Pre-Class Heavy Traffic Alert Banner Overlay
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                PreClassTrafficAlertBanner(
                    alert = activeTrafficAlert,
                    isDarkMode = isDarkMode,
                    isArabic = isArabic,
                    onDismiss = { viewModel.dismissTrafficAlert() },
                    onTakeAlternativeRoute = {
                        viewModel.dismissTrafficAlert()
                    }
                )
            }

            // Top Map Overlay Pills
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.End
            ) {
                // AI Smart Route Pill
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(TertiaryViolet)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = Strings.Map.aiSmartRoute(isArabic),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Traffic Pill
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(PrimaryTeal)
                        )
                        Text(
                            text = Strings.Map.goodTrafficQurum(isArabic),
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Bottom Floating Card (Destination Navigation Card)
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .fillMaxWidth()
                    .testTag("map_navigation_sheet"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    // Drag Handle Line
                    Box(
                        modifier = Modifier
                            .size(width = 48.dp, height = 4.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            .align(Alignment.CenterHorizontally)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = Strings.Map.currentDestination(isArabic),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = Strings.Map.royalOperaHouseMuscat(isArabic),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(SecondaryContainer)
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Stats Grid Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // ETA Box
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = PrimaryTeal,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = Strings.Map.estimatedArrival(isArabic),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = if (isTripStarted)
                                        (Strings.Map.amM(isArabic))
                                    else
                                        (Strings.Map.amM2(isArabic)),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Distance Box
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Route,
                                contentDescription = null,
                                tint = PrimaryTeal,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = Strings.Map.distance(isArabic),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = Strings.Map.km(isArabic),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons Column
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.startTrip() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("start_trip_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isTripStarted) PrimaryTeal else PrimaryContainerTeal,
                                contentColor = if (isTripStarted) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Navigation,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isTripStarted)
                                        (Strings.Map.tripInProgress(isArabic))
                                    else
                                        (Strings.Map.startTrip(isArabic)),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { viewModel.recalculateRoute() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("recalculate_route_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = Strings.Map.recalculateRoute(isArabic),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
