package com.example.ui.screens

import com.example.ui.strings.Strings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.NajdViewModel
import com.example.ui.components.HeaderType
import com.example.ui.components.NajdBottomNavBar
import com.example.ui.components.NajdHeader
import com.example.ui.components.TrafficDashboardCard
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBackgroundLight
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.PrimaryContainerTeal
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.StatusExcellent
import com.example.ui.theme.StatusHeavy
import com.example.ui.theme.StatusLight
import com.example.ui.theme.StatusModerate
import com.example.ui.theme.TertiaryContainerViolet
import com.example.ui.theme.TertiaryViolet

data class BarData(
    val labelAr: String,
    val labelEn: String,
    val valueRatio: Float, // 0.0 to 1.0
    val isAiPeak: Boolean
)

@Composable
fun AnalyticsScreen(
    viewModel: NajdViewModel,
    onNavigate: (String) -> Unit
) {
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isArabic = currentLanguage == "AR"

    var animateBars by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        animateBars = true
    }

    val cardBg = if (isDarkMode) CardBackgroundDark else CardBackgroundLight
    val cardBorder = if (isDarkMode) CardBorderDark else Color.Transparent

    val daysData = listOf(
        BarData("ح", "Sun", 0.65f, false),
        BarData("ن", "Mon", 0.45f, false),
        BarData("ث", "Tue", 0.90f, true),
        BarData("ر", "Wed", 0.55f, false),
        BarData("خ", "Thu", 0.80f, false),
        BarData("ج", "Fri", 0.50f, true),
        BarData("س", "Sat", 0.35f, false)
    )

    Scaffold(
        topBar = {
            NajdHeader(
                title = Strings.Analytics.analyticsDashboard(isArabic),
                headerType = HeaderType.STANDARD,
                isDarkMode = isDarkMode,
                currentLanguage = currentLanguage,
                onToggleDarkMode = { viewModel.toggleDarkMode() },
                onToggleLanguage = { viewModel.toggleLanguage() },
                onLoginClick = { onNavigate("login") }
            )
        },
        bottomBar = {
            NajdBottomNavBar(
                currentScreen = "analytics",
                currentLanguage = currentLanguage,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Last update accent bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(28.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(PrimaryTeal)
                    )
                    Text(
                        text = Strings.Analytics.lastUpdatedMinutesAgo(isArabic),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Real-time Traffic Commute Dashboard Card
                TrafficDashboardCard(
                    isDarkMode = isDarkMode,
                    isArabic = isArabic
                )

                // Stats Cards Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Trips Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .height(120.dp)
                            .testTag("total_trips_stat_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBg),
                        border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = PrimaryTeal,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = Strings.Analytics.totalTrips(isArabic),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = Strings.Analytics.totalTripsCount(isArabic),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryTeal
                                )
                            }
                        }
                    }

                    // Most Used Building Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .height(120.dp)
                            .testTag("top_building_stat_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBg),
                        border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = Icons.Default.Apartment,
                                contentDescription = null,
                                tint = PrimaryTeal,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = Strings.Analytics.mostUsedBuilding(isArabic),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = Strings.Analytics.regionA(isArabic),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryTeal
                                )
                            }
                        }
                    }
                }

                // Weekly Volume Chart Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("weekly_trip_volume_chart"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = Strings.Analytics.weeklyTripVolume(isArabic),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(TertiaryViolet)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "AI OPTIMIZED",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            IconButton(onClick = {}) {
                                Icon(
                                    imageVector = Icons.Default.MoreHoriz,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom Animated Bar Chart
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            daysData.forEach { data ->
                                val targetHeight = if (animateBars) data.valueRatio else 0f
                                val animatedHeight by animateFloatAsState(
                                    targetValue = targetHeight,
                                    animationSpec = tween(durationMillis = 800, delayMillis = 100),
                                    label = "barHeight"
                                )

                                val barBrush = if (data.isAiPeak) {
                                    Brush.verticalGradient(listOf(TertiaryContainerViolet, TertiaryViolet))
                                } else {
                                    Brush.verticalGradient(listOf(PrimaryContainerTeal, PrimaryTeal))
                                }

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(22.dp)
                                            .fillMaxHeight(animatedHeight)
                                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                                            .background(barBrush)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (isArabic) data.labelAr else data.labelEn,
                                        fontSize = 11.sp,
                                        fontWeight = if (data.isAiPeak) FontWeight.Bold else FontWeight.Medium,
                                        color = if (data.isAiPeak) TertiaryViolet else MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        }
                    }
                }

                // Traffic Legend Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("traffic_legend_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = Strings.Analytics.currentTrafficStatusLegend(isArabic),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                LegendItem(StatusExcellent, Strings.Analytics.excellent(isArabic))
                                LegendItem(StatusLight, Strings.Analytics.light(isArabic))
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                LegendItem(StatusModerate, Strings.Analytics.moderate(isArabic))
                                LegendItem(StatusHeavy, Strings.Analytics.heavy(isArabic))
                            }
                        }
                    }
                }

                // AI Predictions Bento Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_predictions_bento_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PrimaryTeal)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = PrimaryContainerTeal,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = Strings.Analytics.aiPredictiveAnalysis(isArabic),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Text(
                            text = Strings.Analytics.basedOnCurrentPatternsWePredict(isArabic),
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.9f),
                            lineHeight = 20.sp
                        )

                        Button(
                            onClick = { onNavigate("map") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("view_recommendations_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryContainerTeal,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        ) {
                            Text(
                                text = Strings.Analytics.viewRecommendations(isArabic),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Circle,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(12.dp)
        )
        Text(
            text = text,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
