package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================
// Najd Design Tokens — matches the approved design system exactly.
// Do NOT introduce new colors here. Every value below must trace
// back to the token table (see Najd_UI_Prompt_Final.md).
// ============================================================

// Primary & Teals
val PrimaryTeal = Color(0xFF037F71)              // Primary Dark Teal (headers, primary text/icons)
val PrimaryTealDarkHeader = Color(0xFF037F71)     // same token, used for Tall/Standard header bg
val PrimaryContainerTeal = Color(0xFF52BCA3)      // Primary Accent (buttons, active states)
val OnPrimaryContainer = Color(0xFF003B38)        // Logo Dark Teal (big numbers, on-accent text)
val PrimaryFixed = Color(0xFFAECFD0)              // Muted Teal Surface (avatar ring, decorative accents)

val SecondaryTeal = Color(0xFF52BCA3)             // maps to Primary Accent (secondary role reuses accent)
val SecondaryContainer = Color(0xFFAECFD0)        // Muted Teal Surface (selected dropdown/chip bg)
val OnSecondaryContainer = Color(0xFF52BCA3)      // Primary Accent (active bottom-nav icon/label)

// AI colors
val TertiaryViolet = Color(0xFF56AEFF)            // AI Route / AI Chart Elements
val TertiaryContainerViolet = Color(0xFF431D63)   // AI Badge background
val OnTertiaryContainer = Color(0xFFFFFFFF)        // AI Badge text (white bold)

// Neutrals Light
val BackgroundLight = Color(0xFFE0E5E9)           // Background
val SurfaceLight = Color(0xFFFFFCF2)              // Main Cards
val CardBackgroundLight = Color(0xFFFFFCF2)       // Main Cards (alias, same token)
val SurfaceContainerLowLight = Color(0xFFFFFFFF)  // Input field background
val SurfaceContainerLight = Color(0xFFFFFFFF)     // Input field background (alias)
val SurfaceContainerHighestLight = Color(0xFFAECFD0) // Muted Teal Surface
val OnSurfaceLight = Color(0xFF2B2F2D)            // Text Primary
val OnSurfaceVariantLight = Color(0xFF333652)     // Text Secondary
val OutlineLight = Color(0xFF333652)              // Text Secondary (used for outline icons/dividers)
val OutlineVariantLight = Color(0xFFC7D9E5)       // Input Border (default)

// Dark-mode-specific brightened variants (per Dark Mode Tokens spec)
val PrimaryTealHeaderDark = Color(0xFF0A5148)     // Primary Dark Teal, darkened for OLED
val AIRouteDark = Color(0xFF6FC2FF)               // AI Route/Chart, brightened for dark bg
val AIBadgeDark = Color(0xFF5A2A82)               // AI Badge bg, brightened for dark bg
val MutedTealSurfaceDark = Color(0xFF2E4B45)      // Muted Teal Surface, dark variant

// Neutrals Dark
val BackgroundDark = Color(0xFF10221F)
val SurfaceDark = Color(0xFF10221F)
val CardBackgroundDark = Color(0xFF16302C)
val SurfaceContainerDark = Color(0xFF1C332F)      // Input Background (dark)
val CardBorderDark = Color(0xFF223B37)
val OnSurfaceDark = Color(0xFFF2F4F2)
val OnSurfaceVariantDark = Color(0xFF9FB3AE)
val OutlineDark = Color(0xFF9FB3AE)
val OutlineVariantDark = Color(0xFF2E4B45)        // Input Border (dark)

// Status Colors — traffic severity (MUST stay exactly these 4 hexes)
val StatusExcellent = Color(0xFF91C059)
val StatusExcellentBg = Color(0xFFFFFCF2)
val StatusLight = Color(0xFFFCC94A)
val StatusLightBg = Color(0xFFFFFCF2)
val StatusModerate = Color(0xFFF49625)
val StatusModerateBg = Color(0xFFFFFCF2)
val StatusHeavy = Color(0xFFDD4E28)
val StatusHeavyBg = Color(0xFFFFFCF2)
val ErrorOrangeRed = Color(0xFFDD4E28)            // Heavy / Error (same token as StatusHeavy)

// Analytics comparison bars
val ChartCompare1 = Color(0xFF8EBD9D)
val ChartCompare2 = Color(0xFF92C3A4)
