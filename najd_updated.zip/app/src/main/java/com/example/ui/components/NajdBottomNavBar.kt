package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SecondaryContainer

@Composable
fun NajdBottomNavBar(
    currentScreen: String,
    currentLanguage: String,
    onNavigate: (String) -> Unit
) {
    val isArabic = currentLanguage == "AR"

    val homeLabel = if (isArabic) "الرئيسية" else "Home"
    val scheduleLabel = if (isArabic) "الجدول" else "Schedule"
    val mapLabel = if (isArabic) "الخريطة" else "Map"
    val analyticsLabel = if (isArabic) "التحليلات" else "Analytics"
    val profileLabel = if (isArabic) "الملف الشخصي" else "Profile"

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Home Tab
            NavItem(
                label = homeLabel,
                isSelected = currentScreen == "home",
                activeIcon = Icons.Filled.Home,
                inactiveIcon = Icons.Outlined.Home,
                testTag = "nav_home_button",
                onClick = { onNavigate("home") }
            )

            // Schedule Tab
            NavItem(
                label = scheduleLabel,
                isSelected = currentScreen == "schedule",
                activeIcon = Icons.Filled.CalendarMonth,
                inactiveIcon = Icons.Outlined.CalendarMonth,
                testTag = "nav_schedule_button",
                onClick = { onNavigate("schedule") }
            )

            // Map Tab
            NavItem(
                label = mapLabel,
                isSelected = currentScreen == "map",
                activeIcon = Icons.Filled.Map,
                inactiveIcon = Icons.Outlined.Map,
                testTag = "nav_map_button",
                onClick = { onNavigate("map") }
            )

            // Analytics Tab
            NavItem(
                label = analyticsLabel,
                isSelected = currentScreen == "analytics",
                activeIcon = Icons.Filled.Analytics,
                inactiveIcon = Icons.Outlined.Analytics,
                testTag = "nav_analytics_button",
                onClick = { onNavigate("analytics") }
            )

            // Profile Tab
            NavItem(
                label = profileLabel,
                isSelected = currentScreen == "profile",
                activeIcon = Icons.Filled.Person,
                inactiveIcon = Icons.Outlined.Person,
                testTag = "nav_profile_button",
                onClick = { onNavigate("profile") }
            )
        }
    }
}

@Composable
private fun NavItem(
    label: String,
    isSelected: Boolean,
    activeIcon: androidx.compose.ui.graphics.vector.ImageVector,
    inactiveIcon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    val containerColor = if (isSelected) SecondaryContainer else Color.Transparent
    val contentColor = if (isSelected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(containerColor)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isSelected) activeIcon else inactiveIcon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = label,
                color = contentColor,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
