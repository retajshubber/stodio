package com.example.ui

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ClassScheduleEntity
import com.example.data.ClassScheduleRepository
import com.example.data.LectureEntity
import com.example.data.LectureRepository
import com.example.data.NajdDatabase
import com.example.ui.strings.Strings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TrafficRoad(
    val nameAr: String,
    val nameEn: String,
    val statusAr: String,
    val statusEn: String,
    val statusType: StatusType
)

enum class StatusType {
    EXCELLENT, LIGHT, MODERATE, HEAVY
}

data class TrafficAlert(
    val id: String = java.util.UUID.randomUUID().toString(),
    val courseCode: String,
    val courseName: String,
    val classTimeSlot: String,
    val minutesBeforeClass: Int = 30,
    val affectedRouteNameAr: String,
    val affectedRouteNameEn: String,
    val estimatedDelayMinutes: Int,
    val recommendedAlternativeAr: String,
    val recommendedAlternativeEn: String,
    val timestamp: Long = System.currentTimeMillis()
)

class NajdViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: LectureRepository
    private val scheduleRepository: ClassScheduleRepository

    val lectures: StateFlow<List<LectureEntity>>
    val classSchedules: StateFlow<List<ClassScheduleEntity>>

    // Traffic Alerts State
    private val _trafficAlertsEnabled = MutableStateFlow(true)
    val trafficAlertsEnabled: StateFlow<Boolean> = _trafficAlertsEnabled.asStateFlow()

    private val _activeTrafficAlert = MutableStateFlow<TrafficAlert?>(null)
    val activeTrafficAlert: StateFlow<TrafficAlert?> = _activeTrafficAlert.asStateFlow()

    private val _trafficAlertHistory = MutableStateFlow<List<TrafficAlert>>(emptyList())
    val trafficAlertHistory: StateFlow<List<TrafficAlert>> = _trafficAlertHistory.asStateFlow()

    init {
        val db = NajdDatabase.getDatabase(application)
        repository = LectureRepository(db.lectureDao())
        scheduleRepository = ClassScheduleRepository(db.classScheduleDao())

        lectures = repository.allLectures.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        classSchedules = scheduleRepository.allSchedules.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        createNotificationChannel()

        viewModelScope.launch {
            repository.prepopulateIfEmpty()
            scheduleRepository.prepopulateIfEmpty()

            // Trigger an initial 30-min pre-class heavy traffic alert demo after prepopulation
            trigger30MinPreClassHeavyTrafficAlert()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "تنبيهات حركة المرور قبل المحاضرات"
            val descriptionText = "تنبيهات تلقائية قبل 30 دقيقة من المحاضرة عند وجود ازدحام مروري"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("traffic_pre_class_alerts", name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getApplication<Application>().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun toggleTrafficAlertsEnabled() {
        _trafficAlertsEnabled.value = !_trafficAlertsEnabled.value
    }

    fun dismissTrafficAlert() {
        _activeTrafficAlert.value = null
    }

    fun trigger30MinPreClassHeavyTrafficAlert() {
        if (!_trafficAlertsEnabled.value) return

        val upcomingClass = classSchedules.value.firstOrNull()
            ?: ClassScheduleEntity(
                courseCode = "CS 301",
                courseName = "هندسة البرمجيات والأنظمة",
                dayOfWeek = "الأحد",
                timeSlot = "08:00 ص - 09:30 ص",
                roomLocation = "مبنى ب - قاعة 102",
                instructorName = "د. أحمد النجدي"
            )

        val alert = TrafficAlert(
            courseCode = upcomingClass.courseCode,
            courseName = upcomingClass.courseName,
            classTimeSlot = upcomingClass.timeSlot,
            minutesBeforeClass = 30,
            affectedRouteNameAr = "شارع الكليات الرئيسي والطريق الأكاديمي",
            affectedRouteNameEn = "Main Academic Avenue & Campus Blvd",
            estimatedDelayMinutes = 22,
            recommendedAlternativeAr = "اسلك المسار الشرقي عبر طريق المجمع العلمي لتفادي الاختناق",
            recommendedAlternativeEn = "Take East Science Campus bypass to avoid heavy delays"
        )

        _activeTrafficAlert.value = alert
        _trafficAlertHistory.value = listOf(alert) + _trafficAlertHistory.value

        sendAndroidNotification(alert)
    }

    private fun sendAndroidNotification(alert: TrafficAlert) {
        try {
            val context = getApplication<Application>()
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val isAr = _currentLanguage.value == "AR"
            val title = if (isAr)
                "🚨 تنبيه ازدحام قبل 30 دقيقة من المحاضرة!"
            else
                "🚨 Heavy Traffic Alert 30m Before Class!"

            val body = if (isAr)
                "محاضرة ${alert.courseCode} تبدأ بعد 30 دقيقة! يوجد ازدحام شديد في ${alert.affectedRouteNameAr} (تأخير +${alert.estimatedDelayMinutes} دقيقة)."
            else
                "Class ${alert.courseCode} starts in 30 mins! Heavy traffic on ${alert.affectedRouteNameEn} (+${alert.estimatedDelayMinutes} min delay)."

            val builder = NotificationCompat.Builder(context, "traffic_pre_class_alerts")
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            notificationManager.notify(1001, builder.build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Navigation & App Settings State
    private val _currentScreen = MutableStateFlow("splash")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _currentLanguage = MutableStateFlow("AR") // "AR" or "EN"
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    // Student Profile State
    private val _studentName = MutableStateFlow("سارة أحمد النجار")
    val studentName: StateFlow<String> = _studentName.asStateFlow()

    private val _studentId = MutableStateFlow("441098231")
    val studentId: StateFlow<String> = _studentId.asStateFlow()

    private val _collegeDepartment = MutableStateFlow("كلية الحاسبات وتقنية المعلومات")
    val collegeDepartment: StateFlow<String> = _collegeDepartment.asStateFlow()

    private val _majorName = MutableStateFlow("هندسة البرمجيات والأنظمة الذكية")
    val majorName: StateFlow<String> = _majorName.asStateFlow()

    private val _academicLevel = MutableStateFlow("السنة الثالثة - المستوى السادس")
    val academicLevel: StateFlow<String> = _academicLevel.asStateFlow()

    private val _studentEmail = MutableStateFlow("sarah.najjar@student.edu.sa")
    val studentEmail: StateFlow<String> = _studentEmail.asStateFlow()

    private val _preferredRoute = MutableStateFlow("طريق المجمع العلمي الشرقي")
    val preferredRoute: StateFlow<String> = _preferredRoute.asStateFlow()

    private val _profileSaveStatus = MutableStateFlow<String?>(null)
    val profileSaveStatus: StateFlow<String?> = _profileSaveStatus.asStateFlow()

    fun updateStudentProfile(
        name: String,
        id: String,
        college: String,
        major: String,
        level: String,
        email: String,
        route: String
    ) {
        _studentName.value = name.ifBlank { _studentName.value }
        _studentId.value = id.ifBlank { _studentId.value }
        _collegeDepartment.value = college.ifBlank { _collegeDepartment.value }
        _majorName.value = major.ifBlank { _majorName.value }
        _academicLevel.value = level.ifBlank { _academicLevel.value }
        _studentEmail.value = email.ifBlank { _studentEmail.value }
        _preferredRoute.value = route.ifBlank { _preferredRoute.value }

        _profileSaveStatus.value = if (_currentLanguage.value == "AR")
            "تم تحديث بيانات الطالب بنجاح!"
        else
            "Student details updated successfully!"
    }

    fun clearProfileSaveStatus() {
        _profileSaveStatus.value = null
    }

    // Login Form State
    var emailInput = MutableStateFlow("sarah.a@domain.com")
    var passwordInput = MutableStateFlow("wrongpassword")
    var loginError = MutableStateFlow(Strings.Login.invalidCredentials(true))

    // Attendance State
    private val _attendanceStatus = MutableStateFlow<String?>(null)
    val attendanceStatus: StateFlow<String?> = _attendanceStatus.asStateFlow()

    // Navigation / Map State
    private val _isTripStarted = MutableStateFlow(false)
    val isTripStarted: StateFlow<Boolean> = _isTripStarted.asStateFlow()

    private val _trafficRoads = MutableStateFlow(
        listOf(
            TrafficRoad("طريق السلطان قابوس", "Sultan Qaboos Highway", "ممتازة", "Excellent", StatusType.EXCELLENT),
            TrafficRoad("شارع 18 نوفمبر", "18th November St", "خفيفة", "Light", StatusType.LIGHT),
            TrafficRoad("طريق مسقط السريع", "Muscat Expressway", "متوسطة", "Moderate", StatusType.MODERATE),
            TrafficRoad("شارع الموج", "Al Mouj St", "مزدحمة", "Heavy", StatusType.HEAVY)
        )
    )
    val trafficRoads: StateFlow<List<TrafficRoad>> = _trafficRoads.asStateFlow()

    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == "AR") "EN" else "AR"
    }

    fun performLogin(onSuccess: () -> Unit) {
        if (emailInput.value.isNotBlank() && passwordInput.value == "123456") {
            loginError.value = ""
            _isLoggedIn.value = true
            onSuccess()
        } else if (passwordInput.value == "wrongpassword") {
            loginError.value = Strings.Login.invalidCredentials(_currentLanguage.value == "AR")
        } else {
            loginError.value = ""
            _isLoggedIn.value = true
            onSuccess()
        }
    }

    fun registerAttendance() {
        _attendanceStatus.value = if (_currentLanguage.value == "AR")
            "تم تسجيل الحضور بنجاح للمحاضرة القادمة (مبادئ العمارة النجدية)!"
        else
            "Attendance registered successfully for the upcoming lecture!"
    }

    fun clearAttendanceDialog() {
        _attendanceStatus.value = null
    }

    fun addLecture(subjectName: String, day: String, startTime: String, location: String) {
        viewModelScope.launch {
            repository.insert(
                LectureEntity(
                    subjectName = subjectName.ifBlank { "مادة جديدة" },
                    day = day,
                    startTime = startTime.ifBlank { "09:00 ص" },
                    location = location.ifBlank { "القاعة الرئيسية" }
                )
            )
        }
    }

    fun deleteLecture(lecture: LectureEntity) {
        viewModelScope.launch {
            repository.delete(lecture)
        }
    }

    fun addClassSchedule(
        courseCode: String,
        courseName: String,
        dayOfWeek: String,
        timeSlot: String,
        roomLocation: String,
        instructorName: String,
        colorTag: String = "#008080"
    ) {
        viewModelScope.launch {
            scheduleRepository.insertSchedule(
                ClassScheduleEntity(
                    courseCode = courseCode.ifBlank { "CS 101" },
                    courseName = courseName.ifBlank { "المقرر الدراسي" },
                    dayOfWeek = dayOfWeek,
                    timeSlot = timeSlot.ifBlank { "09:00 ص - 10:30 ص" },
                    roomLocation = roomLocation.ifBlank { "قاعة 101" },
                    instructorName = instructorName,
                    colorTag = colorTag
                )
            )
        }
    }

    fun deleteClassSchedule(schedule: ClassScheduleEntity) {
        viewModelScope.launch {
            scheduleRepository.deleteSchedule(schedule)
        }
    }

    fun startTrip() {
        _isTripStarted.value = !_isTripStarted.value
    }

    fun recalculateRoute() {
        // Toggle traffic status simulation
        _trafficRoads.value = _trafficRoads.value.shuffled()
    }
}
