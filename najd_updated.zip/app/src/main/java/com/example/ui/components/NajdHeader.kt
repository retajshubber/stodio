package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.PrimaryFixed
import com.example.ui.theme.PrimaryTealDarkHeader

import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AccountCircle

enum class HeaderType {
    DASHBOARD, STANDARD, SIMPLE
}

@Composable
fun NajdHeader(
    title: String = "",
    headerType: HeaderType = HeaderType.STANDARD,
    isDarkMode: Boolean,
    currentLanguage: String,
    onToggleDarkMode: () -> Unit,
    onToggleLanguage: () -> Unit,
    onBackClick: (() -> Unit)? = null,
    onLoginClick: (() -> Unit)? = null
) {
    val isArabic = currentLanguage == "AR"
    val headerBg = when (headerType) {
        HeaderType.DASHBOARD, HeaderType.STANDARD -> PrimaryTealDarkHeader
        HeaderType.SIMPLE -> Color.Transparent
    }
    val contentColor = when (headerType) {
        HeaderType.DASHBOARD, HeaderType.STANDARD -> Color.White
        HeaderType.SIMPLE -> MaterialTheme.colorScheme.onSurface
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(headerBg)
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
            .height(60.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left / Start section (In RTL layout: Start is Right, End is Left. Compose handles direction gracefully)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (onBackClick != null) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("header_back_button")
                    ) {
                        Icon(
                            imageVector = if (isArabic) Icons.AutoMirrored.Filled.ArrowForward else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = contentColor
                        )
                    }
                }

                when (headerType) {
                    HeaderType.DASHBOARD -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.clickable { onLoginClick?.invoke() }
                        ) {
                            // Logo Image
                            Image(
                                painter = painterResource(id = R.drawable.najd_app_icon_1785758181399),
                                contentDescription = "Najd Logo",
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )

                            Column {
                                Text(
                                    text = if (isArabic) "أهلاً بك في نجد" else "Welcome to Najd",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isArabic) "تسجيل الدخول / الحساب" else "Login / Account",
                                    color = PrimaryFixed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    HeaderType.STANDARD -> {
                        // App Logo + Title
                        Image(
                            painter = painterResource(id = R.drawable.najd_app_icon_1785758181399),
                            contentDescription = "Najd Logo",
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Text(
                            text = title.ifEmpty { if (isArabic) "نجد" else "Najd" },
                            color = contentColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    HeaderType.SIMPLE -> {
                        if (title.isNotEmpty()) {
                            Text(
                                text = title,
                                color = contentColor,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Right / Controls section (Login Shortcut + Dark Mode Toggle + Language Toggle)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (onLoginClick != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.15f))
                            .clickable { onLoginClick() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("header_login_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Login,
                                contentDescription = "Login",
                                tint = contentColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isArabic) "دخول" else "Login",
                                color = contentColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Dark Mode Toggle
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .clickable { onToggleDarkMode() }
                        .testTag("toggle_dark_mode_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                        contentDescription = "Toggle Theme",
                        tint = contentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Language Toggle Pill
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .border(
                            width = 1.dp,
                            color = if (headerType == HeaderType.SIMPLE) MaterialTheme.colorScheme.outline else Color.White.copy(alpha = 0.4f),
                            shape = CircleShape
                        )
                        .clickable { onToggleLanguage() }
                        .testTag("toggle_language_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isArabic) "EN" else "عربي",
                        color = contentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
