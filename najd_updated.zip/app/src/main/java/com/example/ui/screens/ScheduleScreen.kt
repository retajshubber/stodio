package com.example.ui.screens

import com.example.ui.strings.Strings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LectureEntity
import com.example.ui.NajdViewModel
import com.example.ui.components.HeaderType
import com.example.ui.components.NajdBottomNavBar
import com.example.ui.components.NajdHeader
import com.example.ui.components.WeeklyClassScheduleComponent
import com.example.ui.theme.CardBackgroundDark
import com.example.ui.theme.CardBackgroundLight
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.ErrorOrangeRed
import com.example.ui.theme.PrimaryContainerTeal
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.PrimaryTealDarkHeader
import com.example.ui.theme.SecondaryContainer
import com.example.ui.theme.TertiaryViolet

@Composable
fun ScheduleScreen(
    viewModel: NajdViewModel,
    onNavigateNext: () -> Unit
) {
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isArabic = currentLanguage == "AR"

    val lectures by viewModel.lectures.collectAsState()
    val classSchedules by viewModel.classSchedules.collectAsState()

    var subjectName by remember { mutableStateOf("") }
    var selectedDay by remember { mutableStateOf(Strings.Schedule.sunday(isArabic)) }
    var startTime by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var isDayDropdownExpanded by remember { mutableStateOf(false) }

    val daysList = if (isArabic) {
        listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس")
    } else {
        listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday")
    }

    val cardBg = if (isDarkMode) CardBackgroundDark else CardBackgroundLight
    val cardBorder = if (isDarkMode) CardBorderDark else Color.Transparent

    Scaffold(
        topBar = {
            NajdHeader(
                title = Strings.Schedule.studentSchedule(isArabic),
                headerType = HeaderType.STANDARD,
                isDarkMode = isDarkMode,
                currentLanguage = currentLanguage,
                onToggleDarkMode = { viewModel.toggleDarkMode() },
                onToggleLanguage = { viewModel.toggleLanguage() },
                onLoginClick = { viewModel.navigateTo("login") }
            )
        },
        bottomBar = {
            NajdBottomNavBar(
                currentScreen = "schedule",
                currentLanguage = currentLanguage,
                onNavigate = { destination ->
                    viewModel.navigateTo(destination)
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Room Database Weekly Class Schedule Matrix Component
            item {
                WeeklyClassScheduleComponent(
                    schedules = classSchedules,
                    isDarkMode = isDarkMode,
                    isArabic = isArabic,
                    onAddSchedule = { code, name, day, time, room, instructor ->
                        viewModel.addClassSchedule(code, name, day, time, room, instructor)
                    },
                    onDeleteSchedule = { schedule ->
                        viewModel.deleteClassSchedule(schedule)
                    }
                )
            }

            // Lecture Form Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_lecture_form"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Subject Name Field
                        Column {
                            Text(
                                text = Strings.Schedule.subjectName(isArabic),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            OutlinedTextField(
                                value = subjectName,
                                onValueChange = { subjectName = it },
                                placeholder = {
                                    Text(
                                        text = Strings.Schedule.eGSoftwareEngineering(isArabic),
                                        fontSize = 14.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Book,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.outline
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("subject_name_input"),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = Color.Transparent
                                ),
                                singleLine = true
                            )
                        }

                        // Day Dropdown Field
                        Column {
                            Text(
                                text = Strings.Schedule.day(isArabic),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            Box {
                                OutlinedTextField(
                                    value = selectedDay,
                                    onValueChange = {},
                                    readOnly = true,
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.CalendarToday,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.outline
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { isDayDropdownExpanded = true }
                                        .testTag("day_select_input"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = Color.Transparent
                                    )
                                )

                                DropdownMenu(
                                    expanded = isDayDropdownExpanded,
                                    onDismissRequest = { isDayDropdownExpanded = false }
                                ) {
                                    daysList.forEach { day ->
                                        DropdownMenuItem(
                                            text = { Text(text = day) },
                                            onClick = {
                                                selectedDay = day
                                                isDayDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Row: Time & Location
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Start Time
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = Strings.Schedule.startTime(isArabic),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                OutlinedTextField(
                                    value = startTime,
                                    onValueChange = { startTime = it },
                                    placeholder = { Text(text = "09:00 ص", fontSize = 14.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Schedule,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.outline
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("start_time_input"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = Color.Transparent
                                    ),
                                    singleLine = true
                                )
                            }

                            // Location
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = Strings.Schedule.locationHall(isArabic),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                OutlinedTextField(
                                    value = location,
                                    onValueChange = { location = it },
                                    placeholder = { Text(text = "G-102", fontSize = 14.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.LocationOn,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.outline
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("location_input"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = Color.Transparent
                                    ),
                                    singleLine = true
                                )
                            }
                        }

                        // Add Button
                        Button(
                            onClick = {
                                viewModel.addLecture(
                                    subjectName = subjectName,
                                    day = selectedDay,
                                    startTime = startTime,
                                    location = location
                                )
                                subjectName = ""
                                startTime = ""
                                location = ""
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("add_lecture_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryContainerTeal,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = Strings.Schedule.addLecture(isArabic),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Section Header
            item {
                Text(
                    text = Strings.Schedule.addedLectures(isArabic),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // Lectures List
            items(
                items = lectures,
                key = { it.id }
            ) { lecture ->
                LectureItemCard(
                    lecture = lecture,
                    isDarkMode = isDarkMode,
                    onDelete = { viewModel.deleteLecture(lecture) }
                )
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun LectureItemCard(
    lecture: LectureEntity,
    isDarkMode: Boolean,
    onDelete: () -> Unit
) {
    val cardBg = if (isDarkMode) CardBackgroundDark else CardBackgroundLight
    val cardBorder = if (isDarkMode) CardBorderDark else Color.Transparent

    val (icon, colorAccent) = when {
        lecture.subjectName.contains("عمارة") || lecture.subjectName.contains("Architecture") ->
            Pair(Icons.Default.Architecture, PrimaryTeal)
        lecture.subjectName.contains("إنجليزية") || lecture.subjectName.contains("English") ->
            Pair(Icons.Default.Language, PrimaryTeal)
        else ->
            Pair(Icons.Default.Functions, TertiaryViolet)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("lecture_card_${lecture.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = if (isDarkMode) androidx.compose.foundation.BorderStroke(1.dp, cardBorder) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(SecondaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column {
                    Text(
                        text = lecture.subjectName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${lecture.startTime} - ${lecture.location}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(PrimaryContainerTeal.copy(alpha = 0.2f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = lecture.day,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = ErrorOrangeRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
